from rest_framework import serializers

from .models import *


class emp_s(serializers.ModelSerializer):
    class Meta:
        model = emp
        fields = '__all__'