from django.apps import AppConfig


class DemoappConfig(AppConfig):
    name = 'demoapp'
    
    def ready(self):
        import demoapp.signals