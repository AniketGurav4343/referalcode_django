from django.shortcuts import render
from django.shortcuts import render

# Create your views here.
from rest_framework.viewsets import ModelViewSet

from demoapp.models import *
from demoapp.serializers import *
from .models import *

# Create your views here.
class emp_view(ModelViewSet):
    queryset = emp.objects.all()
    serializer_class = emp_s

def my_recommendations_view(request):
    profile = Profile.objects.get(user=request.user)
    my_recs = profile.get_recommened_profiles()
    context ={"my_recs":my_recs}
    return render(request, 'my_recs.html',context)